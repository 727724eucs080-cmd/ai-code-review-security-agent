import streamlit as st
from reports.pdf_export import PDFExporter
from reports.json_export import JSONExporter

st.set_page_config(
    page_title="Reports",
    page_icon="📄",
    layout="wide"
)

st.title("📄 Analysis Reports")

if "analysis_result" not in st.session_state:

    st.warning("No report available.")

    st.info("Run Code Analysis first.")

    st.stop()

report = st.session_state["analysis_result"]

# -----------------------------
# Metadata
# -----------------------------

metadata = report["metadata"]

st.subheader("Report Information")

col1, col2 = st.columns(2)

with col1:

    st.metric(

        "Language",

        metadata["language"]

    )

with col2:

    st.metric(

        "Generated",

        metadata["generated_at"]

    )

st.divider()

# -----------------------------
# Preview
# -----------------------------

st.subheader("Preview Report")

st.json(report)

st.divider()

# -----------------------------
# JSON Download
# -----------------------------

json_report = JSONExporter.export(report)

st.download_button(

    label="⬇ Download JSON Report",

    data=json_report,

    file_name="analysis_report.json",

    mime="application/json",

    use_container_width=True

)


pdf_report = PDFExporter.export(report)

st.download_button(

    label="⬇ Download PDF Report",

    data=pdf_report,

    file_name="analysis_report.pdf",

    mime="application/pdf",

    use_container_width=True

)