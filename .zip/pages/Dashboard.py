import streamlit as st
from utils.ui_helper import severity_badge

st.set_page_config(
    page_title="Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("📊 AI Code Review Dashboard")

if "analysis_result" not in st.session_state:

    st.warning("No analysis report available.")

    st.info("Please analyze a source code file first.")

    st.stop()

report = st.session_state["analysis_result"]

# ----------------------------------------------------
# Metadata
# ----------------------------------------------------

metadata = report["metadata"]

st.subheader("Project Information")

col1, col2 = st.columns(2)

with col1:

    st.metric(
        "Language",
        metadata["language"]
    )

with col2:

    st.metric(
        "Generated",
        metadata["generated_at"]
    )

# ----------------------------------------------------
# Syntax Validation
# ----------------------------------------------------

st.divider()

st.subheader("✅ Syntax Validation")

syntax = report["syntax_validation"]

if syntax["valid"]:

    st.success(syntax["message"])

else:

    st.error(syntax["message"])

# ----------------------------------------------------
# Code Analysis
# ----------------------------------------------------

st.divider()

st.subheader("🔍 Code Analysis")

code = report["code_analysis"]["llm"]


st.write(code["summary"])

for finding in code["findings"]:

    st.markdown("---")

    st.write("###", finding["title"])

    severity_badge(finding["severity"])

    st.write("**Description**")

    st.write(finding["description"])

    st.write("**Recommendation**")

    st.success(finding["recommendation"])

# ----------------------------------------------------
# Security Analysis
# ----------------------------------------------------

st.divider()

st.subheader("🛡 Security Analysis")

security = report["security_analysis"]["llm"]

st.write(security["summary"])

for finding in security["findings"]:

    st.markdown("---")

    st.write("###", finding["title"])

    severity_badge(finding["severity"])

    st.write("**Description**")

    st.write(finding["description"])

    st.write("**Recommendation**")

    st.success(finding["recommendation"])

# ----------------------------------------------------
# Remediation
# ----------------------------------------------------

st.divider()

st.subheader("🛠 Remediation")

remediation = report["remediation"]

st.write(remediation["summary"])

if "recommendations" in remediation:

    for rec in remediation["recommendations"]:

        st.markdown("---")

        severity_badge(rec["severity"])

        st.write("###", rec["issue"])

        st.success(rec["recommendation"])


# ----------------------------------------------------
# Pull Request Summary
# ----------------------------------------------------

st.divider()

st.subheader("📝 Pull Request Summary")

pr = report["pr_summary"]

st.write(pr["executive_summary"])