import streamlit as st

from graph.workflow import workflow


st.set_page_config(
    page_title="Code Submission",
    page_icon="💻",
    layout="wide"
)

st.title("💻 AI Code Review & Security Analysis")

st.write(
    "Upload a Python or Java file or paste your source code."
)

uploaded_file = st.file_uploader(
    "Upload Source Code",
    type=["py", "java"]
)

code = ""

if uploaded_file is not None:

    code = uploaded_file.read().decode("utf-8")

else:

    code = st.text_area(
        "Paste Source Code",
        height=350
    )

language = st.selectbox(
    "Programming Language",
    [
        "python",
        "java"
    ]
)

if st.button("🚀 Analyze Code", use_container_width=True):

    if code.strip() == "":

        st.warning("Please upload or paste source code.")

        st.stop()

    state = {

        "code": code,

        "language": language,

        "syntax_valid": False,

        "syntax_message": "",

        "code_analysis": {},

        "security_analysis": {},

        "remediation": {},

        "pr_summary": {},

        "final_report": {}

    }

    with st.spinner("Analyzing source code..."):

        result = workflow.invoke(state)

    st.session_state["analysis_result"] = result["final_report"]

    st.success("Analysis completed successfully.")

    st.info(
        "Open the Dashboard page to view the results."
    )