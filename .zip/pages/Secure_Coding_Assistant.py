import streamlit as st

from rag.retriever import retrieve_documents
from llm.ollama_service import ollama_service

st.set_page_config(
    page_title="Secure Coding Assistant",
    page_icon="🛡️",
    layout="wide"
)

st.title("🛡️ Secure Coding Assistant")

st.write(
    "Ask questions about secure coding, OWASP vulnerabilities, or best practices."
)

question = st.text_area(
    "Enter your question",
    height=120
)

if st.button("Ask Assistant", use_container_width=True):

    if question.strip() == "":

        st.warning("Please enter a question.")

        st.stop()

    with st.spinner("Searching knowledge base..."):

        documents = retrieve_documents(question)

    if not documents:

        st.warning("No relevant documents were found in the knowledge base.")

    else:

        context = "\n\n".join(
            doc.page_content for doc in documents
        )

        prompt = f"""
You are an expert Secure Coding Assistant.

Answer ONLY using the supplied context.

If the answer is not available in the context,
reply politely that the information is unavailable.

Context:

{context}

Question:

{question}
"""

        answer = ollama_service.invoke(prompt)

        st.success("Answer")

        st.write(answer)

        st.divider()

        st.subheader("Retrieved Documents")

        for i, doc in enumerate(documents, start=1):

            with st.expander(f"Document {i}"):

                st.write(doc.page_content)