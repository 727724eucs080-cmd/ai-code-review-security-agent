from datetime import datetime


class ReportBuilder:

    @staticmethod
    def build(state):

        report = {

            "metadata": {

                "generated_at": datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),

                "language": state["language"]

            },

            "syntax_validation": {

                "valid": state["syntax_valid"],

                "message": state["syntax_message"]

            },

            "code_analysis": state["code_analysis"],

            "security_analysis": state["security_analysis"],

            "remediation": state["remediation"],

            "pr_summary": state["pr_summary"]

        }

        return report