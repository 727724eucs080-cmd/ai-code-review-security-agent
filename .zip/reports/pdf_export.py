from io import BytesIO

from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph


class PDFExporter:

    @staticmethod
    def export(report):

        buffer = BytesIO()

        doc = SimpleDocTemplate(buffer)

        styles = getSampleStyleSheet()

        elements = []

        elements.append(
            Paragraph(
                "<b>AI Code Review & Security Analysis Report</b>",
                styles["Title"]
            )
        )

        elements.append(
            Paragraph(
                f"<b>Language:</b> {report['metadata']['language']}",
                styles["Normal"]
            )
        )

        elements.append(
            Paragraph(
                f"<b>Generated:</b> {report['metadata']['generated_at']}",
                styles["Normal"]
            )
        )

        elements.append(
            Paragraph(
                "<br/><b>Syntax Validation</b>",
                styles["Heading2"]
            )
        )

        elements.append(
            Paragraph(
                report["syntax_validation"]["message"],
                styles["Normal"]
            )
        )

        elements.append(
            Paragraph(
                "<br/><b>Code Analysis</b>",
                styles["Heading2"]
            )
        )

        elements.append(
            Paragraph(
                str(report["code_analysis"]),
                styles["Normal"]
            )
        )

        elements.append(
            Paragraph(
                "<br/><b>Security Analysis</b>",
                styles["Heading2"]
            )
        )

        elements.append(
            Paragraph(
                str(report["security_analysis"]),
                styles["Normal"]
            )
        )

        elements.append(
            Paragraph(
                "<br/><b>Remediation</b>",
                styles["Heading2"]
            )
        )

        elements.append(
            Paragraph(
                str(report["remediation"]),
                styles["Normal"]
            )
        )

        elements.append(
            Paragraph(
                "<br/><b>Pull Request Summary</b>",
                styles["Heading2"]
            )
        )

        elements.append(
            Paragraph(
                str(report["pr_summary"]),
                styles["Normal"]
            )
        )

        doc.build(elements)

        pdf = buffer.getvalue()

        buffer.close()

        return pdf