import os

from flask import Flask, render_template, request

from services.report_service import generate_summary

from utils.file_handler import allowed_file

from utils.syntax_checker import (
    check_python_syntax,
    check_java_syntax
)

from utils.code_statistics import (
    get_python_statistics,
    get_java_statistics
)

from orchestrator.analysis_orchestrator import (
    run_analysis
)

from rag.retriever import (
    retrieve_documents
)

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# ==================================================
# HOME PAGE
# ==================================================

@app.route("/", methods=["GET", "POST"])
def home():

    if request.method == "POST":

        uploaded_file = request.files.get(
            "codefile"
        )

        pasted_code = request.form.get(
            "code"
        )

        language = request.form.get(
            "language"
        )

        file_name = ""

        source_code = ""

        statistics = None

        findings = []

        summary = None

        syntax_result = {

            "language": "",

            "status": "",

            "message": ""
        }

        # =====================================
        # FILE UPLOAD
        # =====================================

        if uploaded_file and uploaded_file.filename != "":

            if allowed_file(
                uploaded_file.filename
            ):

                file_name = uploaded_file.filename

                save_path = os.path.join(
                    app.config["UPLOAD_FOLDER"],
                    file_name
                )

                uploaded_file.save(
                    save_path
                )

                with open(
                    save_path,
                    "r",
                    encoding="utf-8"
                ) as file:

                    source_code = file.read()

                if file_name.endswith(".py"):

                    syntax_result = (
                        check_python_syntax(
                            source_code
                        )
                    )

                    statistics = (
                        get_python_statistics(
                            source_code
                        )
                    )

                    findings = (
                        run_analysis(
                            source_code
                        )
                    )

                    summary = generate_summary(
                        findings
                    )

                elif file_name.endswith(".java"):

                    syntax_result = (
                        check_java_syntax(
                            source_code
                        )
                    )

                    statistics = (
                        get_java_statistics(
                            source_code
                        )
                    )

                    findings = (
                        run_analysis(
                            source_code
                        )
                    )

                    summary = generate_summary(
                        findings
                    )

            else:

                syntax_result = {

                    "language": "",

                    "status": "Error",

                    "message":
                    "Only Python (.py) and Java (.java) files are allowed."
                }

        # =====================================
        # PASTED CODE
        # =====================================

        elif pasted_code and pasted_code.strip():

            source_code = pasted_code

            file_name = "Pasted Code"

            if language == "python":

                syntax_result = (
                    check_python_syntax(
                        source_code
                    )
                )

                statistics = (
                    get_python_statistics(
                        source_code
                    )
                )

                findings = (
                    run_analysis(
                        source_code
                    )
                )

                summary = generate_summary(
                    findings
                )

            elif language == "java":

                syntax_result = (
                    check_java_syntax(
                        source_code
                    )
                )

                statistics = (
                    get_java_statistics(
                        source_code
                    )
                )

                findings = (
                    run_analysis(
                        source_code
                    )
                )

                summary = generate_summary(
                    findings
                )

            else:

                syntax_result = {

                    "language": "",

                    "status": "Error",

                    "message":
                    "Please select a programming language."
                }

        # =====================================
        # NO INPUT
        # =====================================

        else:

            syntax_result = {

                "language": "",

                "status": "Error",

                "message":
                "Please upload a file or paste code."
            }

        return render_template(

            "result.html",

            file_name=file_name,

            syntax=syntax_result,

            source_code=source_code,

            statistics=statistics,

            findings=findings,

            summary=summary
        )

    return render_template(
        "index.html"
    )


# ==================================================
# SECURE CODING ASSISTANT
# ==================================================

@app.route(
    "/secure-coding-assistant",
    methods=["GET", "POST"]
)
def secure_coding_assistant():

    results = []

    if request.method == "POST":

        question = request.form.get(
            "question"
        )

        if question:

            results = retrieve_documents(
                question
            )

    return render_template(

        "secure_coding_assistant.html",

        results=results
    )


# ==================================================
# MAIN
# ==================================================

if __name__ == "__main__":

    app.run(
        debug=True
    )