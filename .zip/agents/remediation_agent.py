from typing import Dict, Any


class RemediationAgent:

    """
    Converts findings into actionable fixes.

    No LLM required.
    """

    def generate(self, state) -> Dict[str, Any]:

        recommendations = []

        # ------------------------
        # Code Analysis Findings
        # ------------------------

        findings = state["code_analysis"].get("findings", [])

        for finding in findings:

            recommendations.append({

                "issue": finding.get("title", ""),

                "severity": finding.get("severity", ""),

                "recommendation": finding.get("recommendation", "")

            })

        # ------------------------
        # Security Findings
        # ------------------------

        security = state["security_analysis"].get("llm", {})

        findings = security.get("findings", [])

        for finding in findings:

            recommendations.append({

                "issue": finding.get("title", ""),

                "severity": finding.get("severity", ""),

                "recommendation": finding.get("recommendation", "")

            })

        return {

            "summary": "Generated remediation recommendations.",

            "recommendations": recommendations

        }


remediation_agent = RemediationAgent()