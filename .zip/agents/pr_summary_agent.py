from typing import Dict, Any


class PRSummaryAgent:

    """
    Generates a professional Pull Request summary
    without calling the LLM.
    """

    def generate(self, state) -> Dict[str, Any]:

        code_findings = state["code_analysis"].get("findings", [])

        security_findings = (
            state["security_analysis"]
            .get("llm", {})
            .get("findings", [])
        )

        recommendations = state["remediation"].get(
            "recommendations",
            []
        )

        total = len(code_findings) + len(security_findings)

        critical = 0
        high = 0
        medium = 0
        low = 0

        priority = []

        for finding in code_findings + security_findings:

            severity = finding.get(
                "severity",
                "LOW"
            ).upper()

            if severity == "CRITICAL":
                critical += 1
            elif severity == "HIGH":
                high += 1
            elif severity == "MEDIUM":
                medium += 1
            else:
                low += 1

            priority.append({

                "title": finding.get("title", ""),

                "severity": severity,

                "action": finding.get(
                    "recommendation",
                    ""
                )

            })

        score = max(
            0,
            100 - (
                critical * 25
                + high * 15
                + medium * 8
                + low * 3
            )
        )

        return {

            "executive_summary":
                f"{total} issue(s) detected during analysis.",

            "overall_score": score,

            "statistics": {

                "critical": critical,

                "high": high,

                "medium": medium,

                "low": low,

                "recommendations": len(recommendations)

            },

            "priority": priority

        }


pr_summary_agent = PRSummaryAgent()