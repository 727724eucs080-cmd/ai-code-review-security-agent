import json

from langchain_core.prompts import PromptTemplate

from tools.bandit_tool import BanditTool
from tools.ollama_tool import OllamaTool


class SecurityAgent:

    def __init__(self):

        with open(
            "prompts/security_prompt.txt",
            "r",
            encoding="utf-8"
        ) as f:

            template = f.read()

        self.prompt = PromptTemplate(

            input_variables=[
                "code",
                "bandit_report"
            ],

            template=template

        )

        def analyze(self, code: str, language: str):

            if language.lower() == "python":

                bandit_report = BanditTool.scan(code)

            else:

                bandit_report = {

                    "summary": "Bandit is only applicable to Python.",

                    "results": []

                }   

            
            prompt = self.prompt.format(

                code=code,

                bandit_report=json.dumps(
                    bandit_report,
                    separators=(",", ":")
                )

            )

            response = OllamaTool.generate(prompt)

            response = response.replace("```json", "")
            response = response.replace("```", "")

            try:

                llm = json.loads(response)

            except Exception:

                llm = {

                    "summary": "Unable to parse LLM response.",

                    "findings": [],

                    "raw_response": response

                }

            return {

                "bandit": bandit_report,

                "llm": llm

            }


security_agent = SecurityAgent()