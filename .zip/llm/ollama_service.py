from langchain_ollama import ChatOllama


class OllamaService:
    """
    Centralized LLM service for all AI agents.
    """

    def __init__(self):

        self.llm = ChatOllama(

            model="qwen2.5:3b",

            temperature=0.1,

            num_predict=300,

            num_ctx=2048,

            keep_alive="10m"

        )

    def invoke(self, prompt: str):

        response = self.llm.invoke(prompt)

        return response.content


ollama_service = OllamaService()