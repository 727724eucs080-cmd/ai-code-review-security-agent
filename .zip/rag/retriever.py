from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings

embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

vector_db = None

try:

    vector_db = FAISS.load_local(
        "rag/vector_store",
        embeddings,
        allow_dangerous_deserialization=True
    )

except Exception:

    vector_db = None


def retrieve_documents(query, k=3):

    if vector_db is None:

        return []

    return vector_db.similarity_search(
        query,
        k=k
    )