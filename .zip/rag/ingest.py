import os

from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from chunker import split_documents


def create_vector_database():

    all_chunks = []

    documents_folder = "rag/documents"

    for filename in os.listdir(documents_folder):

        if filename.endswith(".txt"):

            file_path = os.path.join(
                documents_folder,
                filename
            )

            with open(
                file_path,
                "r",
                encoding="utf-8"
            ) as file:

                document = file.read()

                chunks = split_documents(
                    document
                )

                all_chunks.extend(
                    chunks
                )

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vector_db = FAISS.from_texts(
        all_chunks,
        embeddings
    )

    vector_db.save_local(
        "rag/vector_store"
    )

    print(
        "\nVector Database Created Successfully."
    )

    print(
        f"Total Chunks : {len(all_chunks)}"
    )


if __name__ == "__main__":

    create_vector_database()