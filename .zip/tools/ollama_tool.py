from llm.ollama_service import ollama_service


class OllamaTool:

    @staticmethod
    def generate(prompt: str) -> str:

        return ollama_service.invoke(prompt)