import json
import os
import subprocess
import tempfile


class BanditTool:

    @staticmethod
    def scan(code: str):

        try:

            with tempfile.NamedTemporaryFile(
                suffix=".py",
                delete=False,
                mode="w",
                encoding="utf-8"
            ) as temp:

                temp.write(code)

                path = temp.name

            result = subprocess.run(

                [
                    "bandit",
                    "-r",
                    path,
                    "-f",
                    "json"
                ],

                capture_output=True,
                text=True
            )

            os.remove(path)

            if result.stdout:

                return json.loads(result.stdout)

        except Exception as e:

            return {

                "error": str(e),

                "results": []

            }

        return {

            "results": []

        }