import ast
import subprocess
import tempfile
import os


class SyntaxValidator:
    """
    Validates Python and Java source code
    before sending it to AI agents.
    """

    @staticmethod
    def validate_python(code: str):

        try:
            ast.parse(code)

            return {
                "valid": True,
                "message": "Python syntax is valid."
            }

        except SyntaxError as e:

            return {
                "valid": False,
                "message": f"Syntax Error at line {e.lineno}: {e.msg}"
            }

    @staticmethod
    def validate_java(code: str):

        try:

            with tempfile.TemporaryDirectory() as temp_dir:

                file_path = os.path.join(temp_dir, "Temp.java")

                with open(file_path, "w", encoding="utf-8") as file:

                    file.write(code)

                result = subprocess.run(

                    ["javac", file_path],

                    capture_output=True,

                    text=True

                )

                if result.returncode == 0:

                    return {

                        "valid": True,

                        "message": "Java syntax is valid."

                    }

                return {

                    "valid": False,

                    "message": result.stderr

                }

        except FileNotFoundError:

            return {

                "valid": False,

                "message": "Java compiler (javac) not found."

            }

        except Exception as e:

            return {

                "valid": False,

                "message": str(e)

            }

    @staticmethod
    def validate(code: str, language: str):

        language = language.lower()

        if language == "python":

            return SyntaxValidator.validate_python(code)

        elif language == "java":

            return SyntaxValidator.validate_java(code)

        return {

            "valid": False,

            "message": "Unsupported language."

        }